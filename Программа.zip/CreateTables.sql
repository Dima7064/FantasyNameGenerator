﻿CREATE TABLE IF NOT EXISTS Races (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT NOT NULL,
    ConnectingVowels TEXT,
    ConnectingConsonants TEXT,
    ConsonantClusterThreshold INTEGER,
    GlideProbability REAL
);

CREATE TABLE IF NOT EXISTS Categories (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Name TEXT NOT NULL,
    RaceId INTEGER,
    FOREIGN KEY (RaceId) REFERENCES Races(Id)
);

CREATE TABLE IF NOT EXISTS WordParts (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Value TEXT NOT NULL,
    Meaning TEXT NOT NULL,
    PartType INTEGER NOT NULL,
    RaceId INTEGER NOT NULL,
    FOREIGN KEY (RaceId) REFERENCES Races(Id)
);

CREATE TABLE IF NOT EXISTS GenerationRules (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    RaceId INTEGER NOT NULL,
    CategoryId INTEGER NOT NULL,
    MinRoots INTEGER NOT NULL,
    MaxRoots INTEGER NOT NULL,
    PrefixMandatory INTEGER NOT NULL,
    SuffixMandatory INTEGER NOT NULL,
    FOREIGN KEY (RaceId) REFERENCES Races(Id),
    FOREIGN KEY (CategoryId) REFERENCES Categories(Id)
);

CREATE TABLE IF NOT EXISTS Favorites (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Value TEXT NOT NULL,
    Meaning TEXT,
    RaceId INTEGER NOT NULL,
    CategoryId INTEGER NOT NULL,
    CreatedAt TEXT,
    FOREIGN KEY (RaceId) REFERENCES Races(Id),
    FOREIGN KEY (CategoryId) REFERENCES Categories(Id)
);

CREATE TABLE IF NOT EXISTS Blacklist (
    Id INTEGER PRIMARY KEY AUTOINCREMENT,
    Value TEXT NOT NULL,
    Reason TEXT,
    CreatedAt TEXT
);